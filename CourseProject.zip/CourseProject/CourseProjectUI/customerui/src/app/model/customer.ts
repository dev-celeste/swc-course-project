export class customer {
    id: number = 0;
    firstName: string = '';
    lastName: string = '';
    address: string = '';
    city: string = '';
    state: string = '';
    zipcode: number = 0;
    email: string = '';
    phoneNumber: string = '';
}