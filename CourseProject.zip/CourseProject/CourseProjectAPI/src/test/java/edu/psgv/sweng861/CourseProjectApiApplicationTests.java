package edu.psgv.sweng861;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseProjectApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
